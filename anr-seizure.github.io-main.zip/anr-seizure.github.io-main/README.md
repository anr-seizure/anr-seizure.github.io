# SEIZURE ANR website

Website of the SEIZURE project funded by the French National Research Agency (ANR)
The goal of this project is to automatically detect the eplieptogenic zone from multimodality (MRI, PET,MEG and clinical) data based on artificial intelligence.

